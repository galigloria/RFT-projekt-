public class Felhasznalo {
    //Itt hozzuk létre a változókat, ami által tároljuk a felhasználók adatait
    public String nev;
    public  String email;
    public String telefonszam;
    public String lakcim;
    public String jelszo;


}
